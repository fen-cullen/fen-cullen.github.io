#ifndef BLOCK_H
#define BLOCK_H

#if defined(LINUX) || defined(MINGW)
#include <SDL2/SDL.h>
#else
// Windows and Mac use a different path
// If you have compilation errors, change this as needed.
#include <SDL.h>
#endif

#include "Vector2D.h"


const int BLOCK_WIDTH = 60;
const int BLOCK_HEIGHT = 40;

/**
 * Represents a Block with a position. Drawn as a rectangle.
 */
struct Block
{
public:
	Vector2D position;
	SDL_Rect rect{};

	/**
	 * Default constructor
	 */
	Block() {}

	/**
	 * Construct block with a position
	 */
	Block(Vector2D position);

	/**
	 * Destructor
	 */
	~Block();

	/**
	 * Draws block onto the renderer
	 */
	void Draw(SDL_Renderer* renderer);
};


#endif