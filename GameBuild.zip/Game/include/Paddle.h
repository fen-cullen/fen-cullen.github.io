#ifndef PADDLE_H
#define PADDLE_H

#if defined(LINUX) || defined(MINGW)
#include <SDL2/SDL.h>
#else
// Windows and Mac use a different path
// If you have compilation errors, change this as needed.
#include <SDL.h>
#endif

#include "Vector2D.h"


const int PADDLE_WIDTH = 100;
const int PADDLE_HEIGHT = 30;
const float PADDLE_SPEED = 5.0f;


/**
 * Represents a Paddle with position and velocity. Drawn as a rectangle.
 */
struct Paddle
{
public:
	Vector2D position;
	Vector2D velocity;
	SDL_Rect rect{};

	/**
	 * Construct paddle with position and velocity
	 */
	Paddle(Vector2D position, Vector2D velocity);

	/**
	 * destruct paddle
	 */
	~Paddle();

	/**
	 * Moves paddle by velocity
	 */
	void Update();

	//
	/**
	 * Draw paddle onto renderer
	 */
	void Draw(SDL_Renderer* renderer);
};


#endif