#ifndef BALL_H
#define BALL_H

#if defined(LINUX) || defined(MINGW)
#include <SDL2/SDL.h>
#else
// Windows and Mac use a different path
// If you have compilation errors, change this as needed.
#include <SDL.h>
#endif

#include "Vector2D.h"
#include "Contact.h"

struct Contact;

const int BALL_WIDTH = 15;
const int BALL_HEIGHT = 15;
const float BALL_SPEED = 5.0f;


/**
 * Represents a Ball with a position and velocity. Drawn as a rectangle.
 */
struct Ball
{
public:
	Vector2D position;
	Vector2D velocity;
	SDL_Rect rect{};

	/**
	 * Construct ball with position and velocity
	 */
	Ball(Vector2D position, Vector2D velocity);

	/**
	 * Destructor
	 */
	~Ball();

	/**
	 * Moves ball by velocity
	 */
	void Update();

	/**
	 * Draws ball onto the renderer
	 */
	void Draw(SDL_Renderer* renderer);

	/**
	 * Handles collision with the paddle
	 */
	void CollideWithPaddle(Contact const& contact);


	/**
	 * Handles collision with the walls
	 */
	void CollideWithWall(Contact const& contact);

	/**
	 * Handles collision with the block
	 */
	void CollideWithBlock(Contact const& contact);

};


#endif