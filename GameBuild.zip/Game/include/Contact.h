#ifndef CONTACT_H
#define CONTACT_H

#include "Ball.h"
#include "Paddle.h"
#include "Block.h"

struct Ball;

/**
 * Enumerates the types of collisions
 */
enum struct CollisionType
{
	None,
	Top,
	Middle,
	Bottom,
	Left,
	Right
};


/**
 * Represents contact between two objects
 * Type is the type of collision
 * Penetration is how far the objects overlapped
 */
struct Contact
{
public:
	CollisionType type;
	float penetration;
};

/**
 * Collects Contact data between the ball and paddle (possibly no collision)
 */
Contact CheckPaddleCollision(Ball const& ball, Paddle const& paddle);

/**
 * Collects Contact data between the ball and walls (possibly no collision)
 */
Contact CheckWallCollision(Ball const& ball);

/**
 * Collects Contact data between the ball and block (possibly no collision)
 */
Contact CheckBlockCollision(Ball const& ball, Block const& block);

 
#endif