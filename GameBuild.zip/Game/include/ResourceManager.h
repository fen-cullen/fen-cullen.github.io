#ifndef RESOURCEMANAGER_H
#define RESOURCEMANAGER_H

#if defined(LINUX) || defined(MINGW)
#include <SDL2/SDL.h>
#else
// Windows and Mac use a different path
// If you have compilation errors, change this as needed.
#include <SDL.h>
#endif

#include <map>
#include <string>

/**
 * Manages shared game resources such as image textures. A singleton class.
 */
struct ResourceManager {
private:
    std::map < std::string, SDL_Texture* > Map;

    /**
     * Private Constructor
     */
    ResourceManager();

    /**
     * Avoid copy constructor
     */
    ResourceManager(ResourceManager const&) = delete;

    /**
     * Don't allow assignment.
     */
    void operator=(ResourceManager const&) = delete;

public:
    /**
     * Only way to get the one instance of this object
     */
    static ResourceManager& getInstance();

    /**
     * 'equivalent' to our constructor
     */
    int startUp();

    /**
     * 'equivalent' to our destuctor
     */
    int shutDown();

    /**
     * Manage the bmp at filePath. Creates a texture from the bmp at filePath and adds it to Map.
     */
    int Add(const std::string& filePath, SDL_Renderer* renderer);

    /**
     * Gets the texture associated with this filePath
     */
    SDL_Texture* Get(const std::string& filePath);

};


#endif