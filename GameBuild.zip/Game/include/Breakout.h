#ifndef BREAKOUT_HPP
#define BREAKOUT_HPP

#if defined(LINUX) || defined(MINGW)
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_mixer.h>
#else
// Windows and Mac use a different path
// If you have compilation errors, change this as needed.
#include <SDL.h>
#include <SDL_ttf.h>
#include <SDL_mixer.h>
#endif

#include "Block.h"
#include "HUD.h"
#include "Paddle.h"
#include "Ball.h"
#include <list>
#include <memory>


/**
 * This class sets up a Breakout game
 */
struct Breakout {
public:
    /**
     * Constructor. Starts SDL subsystems and initializes all data and objects
     */
    Breakout();

    /**
     * Desctructor. Cleans up memory and shuts down SDL subsystems
     */
    ~Breakout();

    /**
     * Processes user input
     */
    void processInput();

    /**
     * Update game state once per frame
     */
    void update();

    /**
     * Renders shapes to the screen
     */
    void render();

    /**
     * Gameplay loop that runs forever (until player quits or game is over)
     */
    void loop();

private:
    /**
     * Loads blocks according to level file
     */
    void loadLevelBlocks();

    /**
     * Displays win screen and loads next level (or ends game if none)
     */
    void win();

    /**
     * Displays lose screen and ends game
     */
    void lose();


    // The window we'll be rendering to
    SDL_Window* window;
    // SDL Renderer
    SDL_Renderer* renderer;
    // hud font
    TTF_Font* hudFont;
    // win and lose font
    TTF_Font* bigFont;
    // game music
    Mix_Music* music = NULL;
    // block break sound effect
    Mix_Chunk* sfx = NULL;
    // Lose text
    SDL_Texture* loseTexture;
    SDL_Rect loseRect{};
    // Win text
    SDL_Texture* winTexture;
    SDL_Rect winRect{};

    // game state
    bool quit = false;
    int levelNum = 0; // start on level 0
    int score = 0;
    int lives = 3; // start with 3
    int blocksNum;
    
};

#endif