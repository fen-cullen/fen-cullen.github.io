#ifndef VECTOR2D_H
#define VECTOR2D_H

#include <cmath>

/**
 * Vector2D represents a 2D vector or point with float values x and y.
 */
struct Vector2D
{
	float x, y;

    /**
     * Default constructor
     */
	Vector2D() = default;

    /**
     * Constructs vector(a, b)
     */
	Vector2D(float a, float b) {
		x = a;
		y = b;
	}

     /**
      * Multiplication Operator
      * Multiply vector by a uniform-scalar.
      */
    Vector2D& operator *=(float s) {
        x *= s;
        y *= s;
        return (*this);
    }

    /**
     * Division Operator
     */
    Vector2D& operator /=(float s) {
        x /= s;
        y /= s;
        return (*this);
    }

    /**
     * Addition Operator
     */
    Vector2D& operator +=(const Vector2D& v) {
        x += v.x;
        y += v.y;
        return (*this);
    }

    /**
     * Subtraction Operator
     */
    Vector2D& operator -=(const Vector2D& v) {
        x -= v.x;
        y -= v.y;
        return (*this);
    }
};


/**
 * Add two vectors together
 */
inline Vector2D operator +(const Vector2D& a, const Vector2D& b) {
    Vector2D vec = Vector2D(a.x + b.x, a.y + b.y);
    return vec;
}

/**
 * Subtract two vectors
 */
inline Vector2D operator -(const Vector2D& a, const Vector2D& b) {
    Vector2D vec = Vector2D(a.x - b.x, a.y - b.y);
    return vec;
}


/**
 * Compute dot product of two vectors
 */
inline float Dot(const Vector2D& a, const Vector2D& b) {
	return (a.x * b.x) + (a.y * b.y);
}


/**
 * Multiply a vector by a scalar
 */
inline Vector2D operator *(const Vector2D& v, float s) {
	Vector2D vec = Vector2D(v.x * s, v.y * s);
	return vec;
}


/**
 * Division of a vector by a scalar value.
 */
inline Vector2D operator /(const Vector2D& v, float s) {
	Vector2D vec = Vector2D(v.x / s, v.y / s);
	return vec;
}


/**
 * Negate a vector
 */
inline Vector2D operator -(const Vector2D& v) {
	Vector2D vec = Vector2D(-v.x, -v.y);
	return vec;
}


/**
 * Return the magnitude of a vector
 */
inline float Magnitude(const Vector2D& v) {
	return sqrtf(powf(v.x, 2) + powf(v.y, 2));
}


/**
 * Compute the unit vector
 */
inline Vector2D Normalize(const Vector2D& v) {
	Vector2D vec = v / Magnitude(v);
	return vec;
}


#endif