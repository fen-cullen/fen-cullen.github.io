#ifndef HUD_H
#define HUD_H

#if defined(LINUX) || defined(MINGW)
#include <SDL2/SDL_ttf.h>
#else
// Windows and Mac use a different path
// If you have compilation errors, change this as needed.
#include <SDL_ttf.h>
#endif

#include <string>
#include "Vector2D.h"


/**
 * This class handles rendering score text.
 */
struct PlayerScore
{
private:
	SDL_Renderer* renderer;
	TTF_Font* font;
	SDL_Surface* surface{};
	SDL_Texture* texture{};
	SDL_Rect rect{};

public:

	/**
	 * Constructs PlayerScore
	 * Position: text position
	 * Font: text font
	 * Renderer: renderer to draw to
	 */
	PlayerScore(Vector2D position, TTF_Font* font, SDL_Renderer* renderer);

	/**
	 * Destructor
	 */
	~PlayerScore();

	/**
	 * Draws the score text onto the renderer
	 */
	void Draw();

	/**
	 * Updates score text (must Draw() again for it to appear on screen)
	 */
	void SetScore(int score);
};


/**
 * This class handles rendering lives text.
 */
struct PlayerLives
{
private:
	SDL_Renderer* renderer;
	TTF_Font* font;
	SDL_Surface* surface{};
	SDL_Texture* texture{};
	SDL_Rect rect{};

public:
	/**
	 * Constructs PlayerLives
	 * Position: text position
	 * Font: text font
	 * Renderer: renderer to draw to
	 */
	PlayerLives(Vector2D position, TTF_Font* font, SDL_Renderer* renderer);

	/**
	 * Destructor
	 */
	~PlayerLives();

	/**
	 * Draws the lives text onto the renderer
	 */
	void Draw();

	/**
	 * Updates lives text (must Draw() again for it to appear on screen)
	 */
	void SetLives(int & lives);
};

#endif