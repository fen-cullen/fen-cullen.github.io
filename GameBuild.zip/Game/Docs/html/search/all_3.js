var searchData=
[
  ['dot_34',['Dot',['../_vector2_d_8h.html#a081543324d5930ec2b2ca0a93a96cd3e',1,'Vector2D.h']]],
  ['draw_35',['Draw',['../struct_ball.html#a9ed7455edf94a25227ba6b4db451770f',1,'Ball::Draw()'],['../struct_block.html#a655735a0b94b4a14de0b0ce8c56fcefb',1,'Block::Draw()'],['../struct_player_score.html#a464e536f8ed931d91f3e93a782c610bd',1,'PlayerScore::Draw()'],['../struct_player_lives.html#aa18ee8354720b95daad5ba2a7438144e',1,'PlayerLives::Draw()'],['../struct_paddle.html#ab9748edffd50cb22d56425160ac4477a',1,'Paddle::Draw()']]]
];
