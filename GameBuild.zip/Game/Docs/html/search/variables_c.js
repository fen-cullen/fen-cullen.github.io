var searchData=
[
  ['type_218',['type',['../struct_contact.html#a5ebf321b64cf586ddccaebdad562dcd5',1,'Contact']]]
];
