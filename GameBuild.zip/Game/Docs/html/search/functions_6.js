var searchData=
[
  ['magnitude_158',['Magnitude',['../_vector2_d_8h.html#a0e63c94fd17352d9da4844971618e1c8',1,'Vector2D.h']]],
  ['main_159',['main',['../lab_8cpp.html#a3c04138a5bfe5d72780bb7e82a18e627',1,'lab.cpp']]]
];
