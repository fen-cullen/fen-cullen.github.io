var searchData=
[
  ['normalize_160',['Normalize',['../_vector2_d_8h.html#aa9e7037884fe8b98a212394d9c37d14d',1,'Vector2D.h']]]
];
