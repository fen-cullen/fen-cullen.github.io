var searchData=
[
  ['update_180',['Update',['../struct_ball.html#ac2f234d525c0fcf04334ac1d0acf5653',1,'Ball::Update()'],['../struct_paddle.html#a59cd0474cd66883f93aafb0bc926105b',1,'Paddle::Update()']]],
  ['update_181',['update',['../struct_breakout.html#a399a385c58a949d144010ca1e2489397',1,'Breakout']]]
];
