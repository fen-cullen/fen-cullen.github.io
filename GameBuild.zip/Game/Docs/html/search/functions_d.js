var searchData=
[
  ['vector2d_182',['Vector2D',['../struct_vector2_d.html#aa666ef9e6d697c5090f193baefe16f66',1,'Vector2D::Vector2D()=default'],['../struct_vector2_d.html#ab34332f542a2eef92e4a52548f753587',1,'Vector2D::Vector2D(float a, float b)']]]
];
