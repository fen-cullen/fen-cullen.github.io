var searchData=
[
  ['velocity_219',['velocity',['../struct_ball.html#af0a9d4eee0da60d5162c3e09cc805d66',1,'Ball::velocity()'],['../struct_paddle.html#a03d61d861fa67d23d1ca297e2bd240b3',1,'Paddle::velocity()']]]
];
