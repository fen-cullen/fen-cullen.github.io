var searchData=
[
  ['vector2d_99',['Vector2D',['../struct_vector2_d.html',1,'Vector2D'],['../struct_vector2_d.html#aa666ef9e6d697c5090f193baefe16f66',1,'Vector2D::Vector2D()=default'],['../struct_vector2_d.html#ab34332f542a2eef92e4a52548f753587',1,'Vector2D::Vector2D(float a, float b)']]],
  ['vector2d_2eh_100',['Vector2D.h',['../_vector2_d_8h.html',1,'']]],
  ['velocity_101',['velocity',['../struct_ball.html#af0a9d4eee0da60d5162c3e09cc805d66',1,'Ball::velocity()'],['../struct_paddle.html#a03d61d861fa67d23d1ca297e2bd240b3',1,'Paddle::velocity()']]]
];
