var searchData=
[
  ['include_5fdir_44',['INCLUDE_DIR',['../namespacebuild.html#a5d6144bd70c120b901b0047a008b89ad',1,'build']]]
];
