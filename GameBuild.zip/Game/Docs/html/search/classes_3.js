var searchData=
[
  ['resourcemanager_120',['ResourceManager',['../struct_resource_manager.html',1,'']]]
];
