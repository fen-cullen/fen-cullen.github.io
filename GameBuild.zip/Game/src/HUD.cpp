#include "../include/HUD.h"


extern const char* livesString;
extern const char* scoreString;

// PLAYER SCORE

PlayerScore::PlayerScore(Vector2D position, TTF_Font* font, SDL_Renderer* renderer)
	: renderer(renderer), font(font)
{
	surface = TTF_RenderText_Solid(font, "0", { 0xFF, 0xFF, 0xFF, 0xFF });
	texture = SDL_CreateTextureFromSurface(renderer, surface);

	int width, height;
	SDL_QueryTexture(texture, nullptr, nullptr, &width, &height);

	rect.x = static_cast<int>(position.x);
	rect.y = static_cast<int>(position.y);
	rect.w = width;
	rect.h = height;
}

PlayerScore::~PlayerScore()
{
	SDL_FreeSurface(surface);
	SDL_DestroyTexture(texture);
}

void PlayerScore::Draw()
{
	SDL_RenderCopy(renderer, texture, nullptr, &rect);
}

void PlayerScore::SetScore(int score)
{
	SDL_FreeSurface(surface);
	SDL_DestroyTexture(texture);

	std::string text = scoreString + std::to_string(score);

	surface = TTF_RenderText_Solid(font, text.c_str(), { 0xFF, 0xFF, 0xFF, 0xFF });
	texture = SDL_CreateTextureFromSurface(renderer, surface);

	int width, height;
	SDL_QueryTexture(texture, nullptr, nullptr, &width, &height);
	rect.w = width;
	rect.h = height;
}




// PLAYER LIVES

PlayerLives::PlayerLives(Vector2D position, TTF_Font* font, SDL_Renderer* renderer)
	: renderer(renderer), font(font)
{
	surface = TTF_RenderText_Solid(font, "0", { 0xFF, 0xFF, 0xFF, 0xFF });
	texture = SDL_CreateTextureFromSurface(renderer, surface);

	int width, height;
	SDL_QueryTexture(texture, nullptr, nullptr, &width, &height);

	rect.x = static_cast<int>(position.x);
	rect.y = static_cast<int>(position.y);
	rect.w = width;
	rect.h = height;
}

PlayerLives::~PlayerLives()
{
	SDL_FreeSurface(surface);
	SDL_DestroyTexture(texture);
}

void PlayerLives::Draw()
{
	SDL_RenderCopy(renderer, texture, nullptr, &rect);
}

void PlayerLives::SetLives(int & lives)
{
	SDL_FreeSurface(surface);
	SDL_DestroyTexture(texture);

	std::string text = livesString + std::to_string(lives);

	surface = TTF_RenderText_Solid(font, text.c_str(), { 0xFF, 0xFF, 0xFF, 0xFF });
	texture = SDL_CreateTextureFromSurface(renderer, surface);

	int width, height;
	SDL_QueryTexture(texture, nullptr, nullptr, &width, &height);
	rect.w = width;
	rect.h = height;
}