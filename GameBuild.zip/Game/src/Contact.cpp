#include "../include/Contact.h"


extern const int WINDOW_WIDTH;
extern const int WINDOW_HEIGHT;

Contact CheckPaddleCollision(Ball const& ball, Paddle const& paddle)
{
	float ballLeft = ball.position.x;
	float ballRight = ball.position.x + BALL_WIDTH;
	float ballTop = ball.position.y;
	float ballBottom = ball.position.y + BALL_HEIGHT;

	float paddleLeft = paddle.position.x;
	float paddleRight = paddle.position.x + PADDLE_WIDTH;
	float paddleTop = paddle.position.y;
	float paddleBottom = paddle.position.y + PADDLE_HEIGHT;

	Contact contact{};

	if (ballLeft >= paddleRight
		|| ballRight <= paddleLeft
		|| ballTop >= paddleBottom
		|| ballBottom <= paddleTop)
	{
		return contact;
	}

	contact.penetration = ballBottom - paddleTop;

	float paddleRangeRight = paddleLeft + (PADDLE_WIDTH / 2.0f);

	if (ballLeft > paddleRangeRight)
	{
		contact.type = CollisionType::Right;
	}
	else // (ballLeft < paddleRangeRight)
	{
		contact.type = CollisionType::Left;
	}

	return contact;
}


Contact CheckWallCollision(Ball const& ball)
{
	float ballLeft = ball.position.x;
	float ballRight = ball.position.x + BALL_WIDTH;
	float ballTop = ball.position.y;
	float ballBottom = ball.position.y + BALL_HEIGHT;

	Contact contact{};

	if (ballLeft < 0.0f)
	{
		contact.type = CollisionType::Left;
	}
	else if (ballRight > WINDOW_WIDTH)
	{
		contact.type = CollisionType::Right;
	}
	else if (ballTop < 0.0f)
	{
		contact.type = CollisionType::Top;
		contact.penetration = -ballTop;
	}
	else if (ballBottom > WINDOW_HEIGHT)
	{
		contact.type = CollisionType::Bottom;
		contact.penetration = WINDOW_HEIGHT - ballBottom;
	}

	return contact;
}


// Used: https://learnopengl.com/In-Practice/2D-Game/Collisions/Collision-resolution
Contact CheckBlockCollision(Ball const& ball, Block const& block)
{
	Contact contact{};

	float ballLeft = ball.position.x;
	float ballRight = ball.position.x + BALL_WIDTH;
	float ballTop = ball.position.y;
	float ballBottom = ball.position.y + BALL_HEIGHT;

	float blockLeft = block.position.x;
	float blockRight = block.position.x + BLOCK_WIDTH;
	float blockTop = block.position.y;
	float blockBottom = block.position.y + BLOCK_HEIGHT;


	if (ballLeft >= blockRight
		|| ballRight <= blockLeft
		|| ballTop >= blockBottom
		|| ballBottom <= blockTop)
	{
		return contact;
	}

	Vector2D blockCenter = block.position + (Vector2D(BLOCK_WIDTH, BLOCK_HEIGHT) / 2.0f);
	Vector2D ballCenter = ball.position + (Vector2D(BALL_WIDTH, BALL_HEIGHT) / 2.0f);
	Vector2D vec = Normalize(blockCenter - ballCenter);

	// determines which side the ball is closest to
	Vector2D compass[] = {
		Vector2D(0.0f, 1.0f),	// up
		Vector2D(1.0f, 0.0f),	// right
		Vector2D(0.0f, -1.0f),	// down
		Vector2D(-1.0f, 0.0f)	// left
	};

	float max = 0.0f; // 90 degrees
	unsigned int best_match = -1;
	for (unsigned int i = 0; i < 4; i++)
	{
		float dot = Dot(vec, compass[i]);
		if (dot > max)
		{
			max = dot;
			best_match = i;
		}
	}

	switch (best_match)
	{
	case 0:
		contact.type = CollisionType::Top;
		return contact;
	case 1:
		contact.type = CollisionType::Right;
		return contact;
	case 2:
		contact.type = CollisionType::Bottom;
		return contact;
	case 3:
		contact.type = CollisionType::Left;
		return contact;
	}

}