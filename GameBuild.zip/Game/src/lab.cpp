#include "../include/Breakout.h"
#include <string>

extern const char* livesString = NULL;
extern const char* scoreString = NULL;
extern const char* winString = NULL;
extern const char* loseString = NULL;

int main(int argc, char** argv) {
	if (argc < 2 || strcmp(argv[1], "English") == 0) {
		//assume english if language not provided
		printf("Using English\n");
		livesString = "Lives: ";
		scoreString = "Score: ";
		winString = "YOU WIN";
		loseString = "YOU LOSE";
	}
	else if (strcmp(argv[1], "French") == 0) {
		printf("Using French\n");
		livesString = "Vies: ";
		scoreString = "Score: ";
		winString = "TU GAGNES";
		loseString = "TU AS PERDU";
	}
	else {
		printf("Language not supported");
		exit(-1);
	}

	// Create an instance of an object for a SDLGraphicsProgram
	Breakout game = Breakout();
	// Run our program forever
	game.loop();
	// When our program ends, it will exit scope, the
	// destructor will then be called and clean up the program.
	return 0;
}