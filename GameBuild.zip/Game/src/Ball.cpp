#include "../include/Ball.h"


extern const int WINDOW_WIDTH;
extern const int WINDOW_HEIGHT;

Ball::Ball(Vector2D position, Vector2D velocity)
	: position(position), velocity(velocity)
{
	rect.x = static_cast<int>(position.x);
	rect.y = static_cast<int>(position.y);
	rect.w = BALL_WIDTH;
	rect.h = BALL_HEIGHT;
}

Ball::~Ball() {}

void Ball::Update()
{
	position += velocity;
}

void Ball::Draw(SDL_Renderer* renderer)
{
	rect.x = static_cast<int>(position.x);
	rect.y = static_cast<int>(position.y);

	SDL_RenderFillRect(renderer, &rect);
}

void Ball::CollideWithPaddle(Contact const& contact)
{
	position.y -= contact.penetration;
	velocity.y = -velocity.y;

	if ((velocity.x > 0 && contact.type == CollisionType::Left)
		|| (velocity.x < 0 && contact.type == CollisionType::Right))
	{
		velocity.x = -velocity.x;
	}
}

void Ball::CollideWithWall(Contact const& contact)
{
	if ((contact.type == CollisionType::Top))
	{
		position.y += contact.penetration;
		velocity.y = -velocity.y;
	}
	else if ((contact.type == CollisionType::Left)
		|| (contact.type == CollisionType::Right))
	{
		position.x += contact.penetration;
		velocity.x = -velocity.x;
	}

	else if (contact.type == CollisionType::Bottom)
	{
		// reset position and velocity
		position = Vector2D((WINDOW_WIDTH - BALL_WIDTH) / 2, WINDOW_HEIGHT - PADDLE_HEIGHT - BALL_HEIGHT);
		velocity = Normalize(Vector2D(1, -1)) * BALL_SPEED;

	}
}

void Ball::CollideWithBlock(Contact const& contact)
{
	if ((contact.type == CollisionType::Top)
		|| (contact.type == CollisionType::Bottom))
	{
		position.y += contact.penetration;
		velocity.y = -velocity.y;
	}
	else if ((contact.type == CollisionType::Left)
		|| (contact.type == CollisionType::Right))
	{
		position.x += contact.penetration;
		velocity.x = -velocity.x;
	}
}