#include "../include/ResourceManager.h"

#if defined(LINUX) || defined(MINGW)
#include <SDL2/SDL.h>
#else
// Windows and Mac use a different path
// If you have compilation errors, change this as needed.
#include <SDL.h>
#endif

#include <map>
#include <string>


ResourceManager::ResourceManager()
{
    startUp();
}


ResourceManager& ResourceManager::getInstance()
{
    static ResourceManager* instance = new ResourceManager();
    return *instance;
}


int ResourceManager::startUp()
{
	return 0;
}

// 'equivalent' to our destructor
int ResourceManager::shutDown()
{
	// deletes all entries from the map
	std::map< std::string, SDL_Texture* >::iterator it;
	for (it = Map.begin(); it != Map.end(); it++) {
		SDL_DestroyTexture(it->second);
		it = Map.erase(it);
	}
	return 0;
}

int ResourceManager::Add(const std::string& filePath, SDL_Renderer* renderer)
{
	auto it = Map.find(filePath);
	if (it != Map.end())
	{
		return 0; // already in map
	}

	SDL_Log("Allocating memory for bmp");
	SDL_Surface* surface = SDL_LoadBMP(filePath.c_str());

	if (surface == NULL) {
		SDL_Log("Failed to allocate surface");
		SDL_Log(SDL_GetError());
	}
	SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, surface);
	Map.insert(std::pair<std::string, SDL_Texture*>(filePath, texture));
	SDL_FreeSurface(surface);
}

SDL_Texture* ResourceManager::Get(const std::string& filePath)
{
	auto it = Map.find(filePath);
	if (it == Map.end())
	{
		SDL_Log("Error: tried to get resource that doesn't exist");
		return NULL;
	}
	else 
	{
		return it->second; // return texture
	}
}