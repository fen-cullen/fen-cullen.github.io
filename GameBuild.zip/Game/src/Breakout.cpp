#include "../include/Breakout.h"

#if defined(LINUX) || defined(MINGW)
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_mixer.h>
#else
// Windows and Mac use a different path
// If you have compilation errors, change this as needed.
#include <SDL.h>
#include <SDL_ttf.h>
#include <SDL_mixer.h>
#endif

#include <string>
#include <fstream>
#include <sstream>
#include <memory>
#include "../include/Vector2D.h"
#include "../include/HUD.h"
#include "../include/Ball.h"


extern const int WINDOW_WIDTH = 1045;
extern const int WINDOW_HEIGHT = 650;

extern const char* winString;
extern const char* loseString;

const char* HUDFONTPATH = "C:/Users/fencu/Git Repos/monorepo-fen-cullen/Assignment1_Breakout/Game/Assets/font/lazy.ttf";
const char* MUSICPATH = "C:/Users/fencu/Git Repos/monorepo-fen-cullen/Assignment1_Breakout/Game/Assets/music/Beep Boop.mp3";
const char* SFXPATH = "C:/Users/fencu/Git Repos/monorepo-fen-cullen/Assignment1_Breakout/Game/Assets/sound/386862__prof-mudkip__8-bit-explosion.wav";
const char* LVLPATH = "C:/Users/fencu/Git Repos/monorepo-fen-cullen/Assignment1_Breakout/Game/Assets/level/";

const int LASTLEVEL = 2;


std::list< Block > blocks{}; // empty list of blocks
std::shared_ptr< PlayerScore > scoreText(nullptr);
std::shared_ptr< PlayerLives > livesText(nullptr);
std::shared_ptr < Paddle > paddle(nullptr);
std::shared_ptr < Ball > ball(nullptr);
bool goLeft = false;
bool goRight = false;


Breakout::Breakout()
{
	// Initialize SDL components
	if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) != 0) {
		SDL_Log(SDL_GetError());
	}
	if (TTF_Init() != 0) {
		SDL_Log(SDL_GetError());
	}
	// Initialize SDL_mixer
	if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048) != 0) {
		SDL_Log(SDL_GetError());
	}

	// Create window
	window = SDL_CreateWindow("Breakout", 0, 0, WINDOW_WIDTH, WINDOW_HEIGHT, SDL_WINDOW_SHOWN);
	if (window == NULL) {
		SDL_Log(SDL_GetError());
	}

	// Create renderer
	renderer = SDL_CreateRenderer(window, -1, 0);
	if (renderer == NULL) {
		SDL_Log(SDL_GetError());
	}

	// Set up resources

	// Load fonts
	hudFont = TTF_OpenFont(HUDFONTPATH, 40);
	if (hudFont == NULL){
		SDL_Log(SDL_GetError());
	}
	bigFont = TTF_OpenFont(HUDFONTPATH, 100);
	if (bigFont == NULL) {
		SDL_Log(SDL_GetError());
	}

	// Load music
	music = Mix_LoadMUS(MUSICPATH);
	if (music == NULL) {
		SDL_Log(Mix_GetError());
	}

	// Load sound effect
	sfx = Mix_LoadWAV(SFXPATH);
	if (sfx == NULL) {
		SDL_Log(Mix_GetError());
	}

	// Create lose text
	SDL_Surface* surface = TTF_RenderText_Solid(bigFont, loseString, { 0xFF, 0xFF, 0xFF, 0xFF });
	loseTexture = SDL_CreateTextureFromSurface(renderer, surface);
	int width, height;
	SDL_QueryTexture(loseTexture, nullptr, nullptr, &width, &height);
	loseRect.x = (WINDOW_WIDTH - width) / 2;
	loseRect.y = (WINDOW_HEIGHT - height) / 2;
	loseRect.w = width;
	loseRect.h = height;
	SDL_FreeSurface(surface);

	// Create win text
	surface = TTF_RenderText_Solid(bigFont, winString, { 0xFF, 0xFF, 0xFF, 0xFF });
	winTexture = SDL_CreateTextureFromSurface(renderer, surface);
	SDL_QueryTexture(winTexture, nullptr, nullptr, &width, &height);
	winRect.x = (WINDOW_WIDTH - width) / 2;
	winRect.y = (WINDOW_HEIGHT - height) / 2;
	winRect.w = width;
	winRect.h = height;
	SDL_FreeSurface(surface);
	surface = NULL;  // make sure I don't use these again
	width = NULL;
	height = NULL;

	// Create game objects

	// Create blocks for level 0
	loadLevelBlocks();

	// Create the score and lives text fields
	scoreText = std::make_shared< PlayerScore >(Vector2D(WINDOW_WIDTH / 4, 20), hudFont, renderer);
	scoreText->SetScore(score);
	livesText = std::make_shared< PlayerLives>(Vector2D(3 * WINDOW_WIDTH / 4, 20), hudFont, renderer);
	livesText->SetLives(lives);

	// Create paddle at center bottom with velocity zero
	paddle = std::make_shared < Paddle >(Vector2D((WINDOW_WIDTH - PADDLE_WIDTH) / 2, WINDOW_HEIGHT - PADDLE_HEIGHT), Vector2D(0, 0));

	// Create ball at center bottom above paddle with velocity up/right
	ball = std::make_shared < Ball >(Vector2D((WINDOW_WIDTH - BALL_WIDTH) / 2, WINDOW_HEIGHT - PADDLE_HEIGHT - BALL_HEIGHT), Normalize(Vector2D(1, -1)) * BALL_SPEED);

	// Start music (loops forever)
	Mix_PlayMusic(music, -1);
}


Breakout::~Breakout()
{
	// Free resources
	TTF_CloseFont(hudFont);
	TTF_CloseFont(bigFont);
	Mix_FreeMusic(music);
	Mix_FreeChunk(sfx);
	SDL_DestroyTexture(loseTexture);
	SDL_DestroyTexture(winTexture);
	hudFont = NULL;
	bigFont = NULL;
	music = NULL;
	sfx = NULL;
	loseTexture = NULL;
	winTexture = NULL;
	// Destroy window
	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(window);
	renderer = NULL;
	window = NULL;
	// Quit subsystems
	Mix_Quit();
	TTF_Quit();
	SDL_Quit();
}


void Breakout::processInput()
{
	SDL_Event event;
	while (SDL_PollEvent(&event))  //iterates through each event
	{
		if (event.type == SDL_QUIT)
		{
			SDL_Log("quit");
			quit = true;
		}
		// if key is pressed
		else if (event.type == SDL_KEYDOWN)
		{
			SDL_Log("keydown");
			switch (event.key.keysym.sym)
			{
			case SDLK_q:
				SDL_Log("quit");
				quit = true;
				break;
			case SDLK_a:
				goLeft = true;
				break;
			case SDLK_d:
				goRight = true;
				break;
			case SDLK_LEFT:
				goLeft = true;
				break;
			case SDLK_RIGHT:
				goRight = true;
				break;
			default:
				break;
			}
		}
		// if key is released
		else if (event.type == SDL_KEYUP)
		{
			SDL_Log("keyup");
			switch (event.key.keysym.sym)
			{
			case SDLK_a:
				goLeft = false;
				break;
			case SDLK_d:
				goRight = false;
				break;
			case SDLK_LEFT:
				goLeft = false;
				break;
			case SDLK_RIGHT:
				goRight = false;
				break;
			default:
				break;
			}
		}
	}

	if (goRight && !goLeft)
	{
		SDL_Log("right");
		paddle->velocity.x = PADDLE_SPEED;
	}
	else if (goLeft && !goRight)
	{
		SDL_Log("left");
		paddle->velocity.x = -PADDLE_SPEED;
	}
	else
	{
		paddle->velocity.x = 0;
	}
}


void Breakout::update() 
{
	paddle->Update();

	ball->Update();

	// check collisions
	if (Contact contact = CheckPaddleCollision(*ball, *paddle);
		contact.type != CollisionType::None)
	{
		ball->CollideWithPaddle(contact);
		Mix_PlayChannel(-1, sfx, 0);  // play sfx
	}
	else if (Contact contact = CheckWallCollision(*ball);
		contact.type != CollisionType::None)
	{
		ball->CollideWithWall(contact);
		Mix_PlayChannel(-1, sfx, 0);  // play sfx
		// if it hit the bottom, lose a life
		if (contact.type == CollisionType::Bottom) {
			livesText->SetLives(--lives);
		}
	}
	else
	{
		auto it = blocks.begin();
		while (it != blocks.end())
		{
			if (Contact contact = CheckBlockCollision(*ball, *it);
				contact.type != CollisionType::None)
			{
				ball->CollideWithBlock(contact);
				Mix_PlayChannel(-1, sfx, 0);  // play sfx
				it = blocks.erase(it);  // remove block from list
				scoreText->SetScore(++score);  // increase score
			}
			else {
				++it;
			}
		}
	}

	// check if win or lose
	if (lives <= 0)
	{
		lose();
	}
	if (score >= blocksNum)
	{
		win();
	}
}


void Breakout::render()
{
	// Clear the window to black
	SDL_SetRenderDrawColor(renderer, 0x0, 0x0, 0x0, 0xFF);
	SDL_RenderClear(renderer);

	// Set the draw color to be white
	SDL_SetRenderDrawColor(renderer, 0xFF, 0xFF, 0xFF, 0xFF);

	// Draw the ball
	ball->Draw(renderer);

	// Draw the paddle
	paddle->Draw(renderer);

	// Draw the blocks
	auto it = blocks.begin();
	while (it != blocks.end())
	{
		it->Draw(renderer);
		++it;
	}

	// Display score and lives
	scoreText->Draw();
	livesText->Draw();

	// Present the backbuffer
	SDL_RenderPresent(renderer);
}


void Breakout::loop()
{
	// all time is in milliseconds
	float dt = 0.0f;  // milliseconds per frame

	unsigned int countOneSecond = 0;  // counts down to one second
	unsigned int fps = 0;  // counts # of frames in each second
	unsigned int prevTime = 0; // runtime (last frame)
	unsigned int newTime = 0;  // runtime (this frame)

	// loops until player quit or game is over
	while (!quit) 
	{
		// cap 60 fps
		newTime = SDL_GetTicks();
		dt = newTime - prevTime;
		// 1000/60 = ms per frame for 60 fps
		if (dt < (1000.f / 60.f)) {
			SDL_Delay((Uint32)(1000.f / 60.f) - dt);
			newTime = SDL_GetTicks();
		}

		prevTime = newTime;
		if (newTime > (countOneSecond + 1000.f)) {
			SDL_Log("FPS: %u\n", fps);
			countOneSecond = newTime;
			fps = 0;
		}

		processInput();

		update();

		render();

		fps++;
	}
	//Disable keyboard input
	SDL_StopTextInput();
}

void Breakout::loadLevelBlocks() 
{
	int buffer = 5;
	int xSum = buffer;  // counts xpos of each block
	int ySum = buffer;  // counts ypos of each block

	// opens the file into a stream
	std::ifstream lvlStream (LVLPATH + std::to_string(levelNum) + ".txt", std::ifstream::in);
	if (lvlStream.fail()) {
		SDL_Log("Stream failed to open");
	}

	// read each line and open it into a stream
	while (lvlStream.good()) 
	{
		char line[256];
		lvlStream.getline(line, 256);
		std::stringstream lineStream(line, std::stringstream::in);
		// read each int from the line
		while (lineStream.good())
		{
			int data;
			lineStream >> data;

			// create block from data
			// if data == 0, no block
			if (data == 1) 
			{
				blocks.push_back(Block(Vector2D(xSum, ySum)));  //push block onto list
			}
			xSum = xSum + BLOCK_WIDTH + buffer; // set to next column
		}
		lineStream.clear();
		xSum = buffer;  // reset xSum
		ySum = ySum + BLOCK_HEIGHT + buffer;  // set to next row
	}
	lvlStream.close();
	blocksNum = blocks.size();
}


void Breakout::win() 
{
	SDL_RenderCopy(renderer, winTexture, nullptr, &winRect);
	SDL_RenderPresent(renderer);
	SDL_Delay(2000);  // wait for 2 seconds
	// next level
	++levelNum;
	// if next level file exists, load level
	if (levelNum <= LASTLEVEL)
	{
		score = 0;
		lives = 3;
		blocks.clear();
		loadLevelBlocks();
		// reset paddle position and velocity
		paddle->position = Vector2D((WINDOW_WIDTH - PADDLE_WIDTH) / 2, WINDOW_HEIGHT - PADDLE_HEIGHT);
		paddle->velocity = Vector2D(0, 0);
		// reset ball position and velocity
		ball->position = Vector2D((WINDOW_WIDTH - BALL_WIDTH) / 2, WINDOW_HEIGHT - PADDLE_HEIGHT - BALL_HEIGHT);
		ball->velocity = Normalize(Vector2D(1, -1)) * BALL_SPEED;
	}
	else {
		quit = true;
	}

}


void Breakout::lose()
{
	SDL_RenderCopy(renderer, loseTexture, nullptr, &loseRect);
	SDL_RenderPresent(renderer);
	SDL_Delay(2000);  // wait for 2 seconds
	quit = true;  // end game
}