#include "../include/Block.h"

Block::Block(Vector2D position)
	: position(position)
{
	rect.x = static_cast<int>(position.x);
	rect.y = static_cast<int>(position.y);
	rect.w = BLOCK_WIDTH;
	rect.h = BLOCK_HEIGHT;
}

Block::~Block() {}

void Block::Draw(SDL_Renderer* renderer) 
{
	// set draw color blue
	SDL_SetRenderDrawColor(renderer, 0x00, 0x00, 0xFF, 0xFF);
	// draw in the rectangle
	SDL_RenderFillRect(renderer, &rect);
}