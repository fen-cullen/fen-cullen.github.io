#include "../include/Paddle.h"
#include <string>

extern const int WINDOW_WIDTH;
extern const int WINDOW_HEIGHT;

Paddle::Paddle(Vector2D position, Vector2D velocity)
	: position(position), velocity(velocity)
{
	rect.x = static_cast<int>(position.x);
	rect.y = static_cast<int>(position.y);
	rect.w = PADDLE_WIDTH;
	rect.h = PADDLE_HEIGHT;
}

Paddle::~Paddle() {}

void Paddle::Update()
{
	position += velocity;

	if (position.x < 0)
	{
		// Restrict to left side of the screen
		position.x = 0;
	}
	else if (position.x > (WINDOW_WIDTH - PADDLE_WIDTH))
	{
		// Restrict to right side of the screen
		position.x = WINDOW_WIDTH - PADDLE_WIDTH;
	}
}

void Paddle::Draw(SDL_Renderer* renderer)
{
	// its only moving on the x axis
	rect.x = static_cast<int>(position.x);

	SDL_RenderFillRect(renderer, &rect);
}